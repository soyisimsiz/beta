# Beta Yapı İnşaat – SEO İçerik Paketi

## Paket İçeriği

Bu paket, betayapinsaat.com.tr sitesi için hazırlanmış kapsamlı SEO içerik setini içermektedir.

### Klasör Yapısı

```
/seo-paketi/
├── 00-README.md                  ← Bu dosya
├── 01-ana-landing-pages/         ← 3 ana hizmet sayfası (HTML)
│   ├── prefabrik-ev-canakkale.html
│   ├── celik-ev-canakkale.html
│   └── konteyner-ev-canakkale.html
├── 02-ilce-pages/                ← 12 ilçe sayfası (HTML)
│   ├── biga-prefabrik-ev.html
│   ├── gelibolu-prefabrik-ev.html
│   ├── ezine-prefabrik-ev.html
│   ├── ayvacik-prefabrik-ev.html
│   ├── lapseki-prefabrik-ev.html
│   ├── can-celik-ev.html
│   ├── bayramic-celik-ev.html
│   ├── yenice-celik-ev.html
│   ├── eceabat-konteyner-ev.html
│   ├── bozcaada-konteyner-ev.html
│   ├── gokceada-konteyner-ev.html
│   └── merkez-prefabrik-ev.html
├── 03-blog-icerikler/            ← 10 blog yazısı (Markdown)
│   ├── prefabrik-ev-fiyatlari-2026.md
│   ├── celik-ev-mi-prefabrik-ev-mi.md
│   ├── konteyner-ev-ruhsat-rehberi.md
│   ├── canakkale-prefabrik-ev-kurulum-sureci.md
│   ├── prefabrik-ev-avantajlari-dezavantajlari.md
│   ├── deprem-bolgesinde-celik-ev.md
│   ├── konteyner-ev-yalitim-rehberi.md
│   ├── prefabrik-villa-modelleri.md
│   ├── tiny-house-vs-konteyner-ev.md
│   └── prefabrik-ev-bakim-rehberi.md
├── 04-schema-markup/             ← 5 JSON-LD dosyası
│   ├── localbusiness.json
│   ├── product-prefabrik.json
│   ├── product-celik.json
│   ├── product-konteyner.json
│   └── faqpage-template.json
├── 05-meta-tablosu.csv           ← Tüm 15 sayfanın meta bilgileri
└── 06-gmb-optimizasyon-checklist.md ← Google İşletme Profili rehberi
```

## Siteye Yükleme Rehberi

### Adım 1: Ana Landing Page'leri Yükle (Öncelik: YÜKSEK)
1. `01-ana-landing-pages/` klasöründeki 3 HTML dosyasını GitHub repo'ya yükleyin.
2. Her dosya kendi URL'sinde yer almalıdır:
   - `prefabrik-ev-canakkale.html` → `betayapinsaat.com.tr/prefabrik-ev-canakkale/`
   - `celik-ev-canakkale.html` → `betayapinsaat.com.tr/celik-ev-canakkale/`
   - `konteyner-ev-canakkale.html` → `betayapinsaat.com.tr/konteyner-ev-canakkale/`
3. GitHub Pages'te clean URL için her birini bir klasör altında `index.html` olarak da düzenleyebilirsiniz:
   - `/prefabrik-ev-canakkale/index.html`
   - `/celik-ev-canakkale/index.html`
   - `/konteyner-ev-canakkale/index.html`

### Adım 2: İlçe Sayfalarını Yükle (Öncelik: YÜKSEK)
1. `02-ilce-pages/` klasöründeki 12 HTML dosyasını aynı yöntemle yükleyin.
2. URL yapısı:
   - `biga-prefabrik-ev.html` → `/biga-prefabrik-ev/index.html`
   - (diğerleri aynı mantıkla)

### Adım 3: Blog İçeriklerini Yükle (Öncelik: ORTA)
1. `03-blog-icerikler/` klasöründeki Markdown dosyaları blog sayfalarına dönüştürülmelidir.
2. GitHub Pages + Jekyll kullanıyorsanız, `_posts/` klasörüne taşıyıp dosya adı başına tarih ekleyin:
   - `2026-01-15-prefabrik-ev-fiyatlari-2026.md`
   - (frontmatter zaten mevcut)
3. Statik HTML site kullanıyorsanız, Markdown'ları HTML'e çevirin (örneğin pandoc veya online converter ile).

### Adım 4: Schema Markup Entegrasyonu (Öncelik: YÜKSEK)
1. `04-schema-markup/localbusiness.json` → Ana sayfa (`index.html`) `<head>` bölümüne `<script type="application/ld+json">` olarak ekleyin. Tüm sayfalarda görünmeli.
2. `product-prefabrik.json` → Prefabrik ev landing page'e ekleyin (zaten HTML içinde mevcut, doğrulama yapın).
3. `product-celik.json` → Çelik ev landing page'e ekleyin.
4. `product-konteyner.json` → Konteyner ev landing page'e ekleyin.
5. `faqpage-template.json` → İlçe sayfalarına SSS eklediğinizde bu template'i kullanın.

### Adım 5: Meta Tablosunu Kontrol Et (Öncelik: ORTA)
1. `05-meta-tablosu.csv` dosyasını açın ve tüm sayfaların meta bilgilerini sitenizle karşılaştırın.
2. Eksik veya hatalı meta title/description varsa düzeltin.

### Adım 6: GMB Optimizasyonu (Öncelik: YÜKSEK)
1. `06-gmb-optimizasyon-checklist.md` dosyasını takip ederek Google İşletme Profilinizi optimize edin.
2. İlk 30 gün post planını uygulayın.
3. Fotoğraf yüklemelerine başlayın.

## Yükleme Sırası (Önerilen)

| Sıra | İşlem | Süre |
|------|-------|------|
| 1 | Schema markup (localbusiness.json) ana sayfaya ekle | 15 dk |
| 2 | 3 ana landing page yükle | 30 dk |
| 3 | 12 ilçe sayfası yükle | 1 saat |
| 4 | GMB profilini optimize et | 2 saat |
| 5 | Blog içeriklerini HTML'e çevir ve yükle | 2-3 saat |
| 6 | Tüm sayfaların meta bilgilerini doğrula | 30 dk |
| 7 | Google Search Console'da sitemap gönder | 15 dk |

## Yapılması Gerekenler (Elle Doldurulacak)

- [ ] `[TELEFON]` placeholder'larını gerçek telefon numarasıyla değiştirin (tüm dosyalarda bul-değiştir yapın)
- [ ] `[ADRES]` placeholder'ını gerçek adresle değiştirin (localbusiness.json)
- [ ] Fotoğraflar ekleyin (OG image URL'lerini güncelleyin)
- [ ] Google Analytics tracking kodu ekleyin
- [ ] Google Search Console doğrulama dosyası ekleyin
- [ ] Sitemap.xml oluşturup gönderin
- [ ] Robots.txt dosyasını güncelleyin
- [ ] Sosyal medya URL'lerini güncelleyin (localbusiness.json)
- [ ] Fiyatları periyodik olarak güncelleyin

## Sonraki Adımlar

1. **Google Search Console:** Siteyi doğrulayın, sitemap gönderin, indeksleme talep edin.
2. **Backlink:** Yerel dizinlere (Çanakkale ticaret odası, sanayi odası, yerel rehberler) kayıt olun.
3. **Sosyal Medya:** Blog içeriklerini Instagram, Facebook ve LinkedIn'de paylaşın.
4. **İçerik Güncellemesi:** 3 ayda bir fiyat tablolarını güncelleyin, yeni blog yazıları ekleyin.
5. **Performans Takibi:** Google Analytics ve Search Console verilerini aylık inceleyin.
