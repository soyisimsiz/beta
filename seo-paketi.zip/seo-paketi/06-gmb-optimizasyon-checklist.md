# Google My Business (Google İşletme Profili) Optimizasyon Checklist

## 1. Temel Bilgiler

### Birincil Kategori
- **Prefabricated House Dealer** (Prefabrik Ev Satıcısı)

### İkincil Kategoriler
- Building Materials Supplier (Yapı Malzemesi Tedarikçisi)
- General Contractor (Genel Müteahhit)
- Construction Company (İnşaat Şirketi)
- Steel Fabricator (Çelik İmalat)

### Doldurulacak Alanlar Listesi

| Alan | Durum | Açıklama |
|------|-------|----------|
| İşletme adı | Doldur | "Beta Yapı İnşaat" (marka adı, anahtar kelime ekleme) |
| Adres | Doldur | Tam adres, harita pini doğrula |
| Telefon | Doldur | Ana hat + WhatsApp numarası |
| Web sitesi | Doldur | https://betayapinsaat.com.tr |
| Çalışma saatleri | Doldur | Pzt-Cum 08:30-18:00, Cmt 09:00-14:00 |
| Hizmet alanları | Doldur | Çanakkale + 12 ilçe tek tek ekle |
| İşletme açıklaması | Doldur | 750 karakter, anahtar kelimeler doğal yerleştirilmiş |
| Kuruluş yılı | Doldur | Şirket kuruluş yılı |
| Randevu bağlantısı | Doldur | WhatsApp veya form linki |
| Ürünler/Hizmetler | Doldur | Aşağıdaki listeye göre |

## 2. Yüklenecek Fotoğraf Tipleri

| Fotoğraf Tipi | Önerilen Sayı | Açıklama |
|---------------|---------------|----------|
| Logo | 1 | Şeffaf arka plan, yüksek çözünürlük |
| Kapak fotoğrafı | 1 | En etkileyici tamamlanmış proje |
| Dış cephe (ofis) | 3-5 | İşletme binasının farklı açılardan görünümü |
| Tamamlanmış projeler | 15-20 | Her proje türünden (prefabrik, çelik, konteyner) |
| Kurulum süreci | 8-10 | Temel, montaj, yalıtım, iç mekan aşamaları |
| Ekip fotoğrafları | 3-5 | Montaj ekibi çalışırken, müşteri ile fotoğraf |
| İç mekan | 10-15 | Mutfak, salon, yatak odası, banyo örnekleri |
| Malzeme kalitesi | 3-5 | Çelik profiller, yalıtım, panel detayları |
| Müşteri teslimatı | 5-8 | Anahtar teslim anları (izinli) |
| Video | 3-5 | Drone çekim, kurulum timelapse, müşteri yorumu |

**Toplam önerilen: Minimum 50 fotoğraf + 3 video**

## 3. Ürün/Hizmet Listesi Formatı

GMB'de "Ürünler" sekmesine eklenecek öğeler:

### Prefabrik Ev Modelleri
- **Beta Starter (50 m²)** – 1+1 prefabrik ev, 850.000 TL'den başlayan fiyatlarla
- **Beta Comfort (80 m²)** – 2+1 prefabrik ev, genç aileler için ideal
- **Beta Family (110 m²)** – 3+1 prefabrik ev, tek veya çift kat seçeneği
- **Beta Premium (140 m²)** – 4+1 prefabrik ev, çift katlı lüks yapı
- **Beta Villa (180 m²)** – 4+2 prefabrik villa, teras ve garaj opsiyonlu

### Çelik Ev Modelleri
- **Çelik Compact (60 m²)** – 1+1 çelik ev, müstakil veya yazlık
- **Çelik Aile (90 m²)** – 2+1 çelik ev, depreme dayanıklı
- **Çelik Konfor (120 m²)** – 3+1 çelik ev, üstün yalıtım
- **Çelik Villa (200 m²)** – 5+1 çelik villa, tam donanımlı

### Konteyner Ev Modelleri
- **Mini Konteyner (18 m²)** – Ofis, kafe, depo kullanımı
- **Standart Konteyner (21 m²)** – Stüdyo ev, yazlık, tarla evi
- **Çift Konteyner (42 m²)** – 1+1 modüler ev
- **Villa Konteyner (84 m²)** – 3+1 birleşik konteyner ev

### Hizmetler
- **Ücretsiz Keşif ve Arazi İnceleme**
- **Mimari Proje Tasarımı**
- **Ruhsat ve İzin Takibi**
- **Anahtar Teslim Kurulum**
- **Satış Sonrası Bakım ve Destek**

## 4. İlk 30 Günde Paylaşılacak Post Fikirleri

| Hafta | Post Konusu | Post Tipi |
|-------|------------|-----------|
| 1 | "Çanakkale'de 93+ Tamamlanmış Proje – Beta Yapı İnşaat" + En iyi proje fotoğrafı | Güncelleme + Fotoğraf |
| 1 | "2026 Prefabrik Ev Fiyatları – Güncel Liste" + Fiyat tablosu görseli | Teklif + Fotoğraf |
| 2 | "Biga'da Tamamladığımız Son Projemiz" + Before/After fotoğrafları | Güncelleme + Fotoğraf |
| 2 | "Çelik Ev vs Betonarme – Deprem Güvenliği Karşılaştırması" + Infografik | Güncelleme + Fotoğraf |
| 3 | "%20 Erken Rezervasyon İndirimi – Yaz Sezonuna Hazır Olun" | Teklif |
| 3 | "Konteyner Ev ile Bozcaada'da Bağ Evi Hayalinizi Gerçekleştirin" | Güncelleme + Fotoğraf |
| 4 | "Prefabrik Ev Kurulum Süreci – 10 Adımda Anahtar Teslim" + Video/timelapse | Güncelleme + Video |
| 4 | "Müşteri Yorumu: Gelibolu'da Prefabrik Evimiz" + Müşteri fotoğrafı | Güncelleme + Fotoğraf |
| 5 | "Ücretsiz Keşif Haftası – Çanakkale Geneli" + CTA | Teklif |
| 5 | "Çanakkale İkliminde Yapı Yalıtımının Önemi" + Teknik bilgi görseli | Güncelleme + Fotoğraf |

## 5. GMB Sıkça Sorulan Sorular (8 Adet)

### S1: Prefabrik ev fiyatları ne kadar?
**C:** 2026 yılında prefabrik ev fiyatlarımız 850.000 TL'den başlamaktadır. Fiyat, metrekare, model seçimi ve iç donanım paketine göre değişir. Ücretsiz keşif sonrası size özel fiyat teklifi sunuyoruz.

### S2: Çanakkale'nin hangi ilçelerine hizmet veriyorsunuz?
**C:** Çanakkale merkez dahil tüm ilçelere hizmet veriyoruz: Biga, Gelibolu, Ezine, Ayvacık, Lapseki, Çan, Bayramiç, Yenice, Eceabat, Bozcaada ve Gökçeada.

### S3: Prefabrik ev kurulumu ne kadar sürer?
**C:** Temel dahil anahtar teslim kurulum 30-45 iş günü içinde tamamlanır. Konteyner evlerde bu süre 7-15 gündür. Hava koşulları ve arazi durumuna göre değişiklik gösterebilir.

### S4: Prefabrik evler depreme dayanıklı mı?
**C:** Evet. Tüm yapılarımız TBDY 2018 deprem yönetmeliğine uygun olarak üretilir. Hafif çelik karkas sistemi, 1. derece deprem bölgelerinde bile güvenle kullanılabilir.

### S5: Banka kredisi kullanabilir miyim?
**C:** Evet. İskan belgeli prefabrik ve çelik evler için birçok banka konut kredisi kullandırmaktadır. Kredi süreçlerinde danışmanlık desteği sunuyoruz.

### S6: Garanti süresi ne kadar?
**C:** 2 yıl yapısal garanti ve ömür boyu teknik destek hizmeti sunuyoruz. Periyodik bakım sözleşmesiyle kapsamlı koruma sağlıyoruz.

### S7: Özel tasarım proje yapıyor musunuz?
**C:** Evet. Standart modellerimizin yanı sıra tamamen size özel mimari proje tasarımı da yapıyoruz. 3D modelleme ile evinizi kurulmadan önce görmeniz sağlanır.

### S8: Konteyner evler ada ilçelerine (Bozcaada, Gökçeada) nasıl ulaştırılır?
**C:** Konteyner evler fabrikamızda komple üretilip tır üzerinde feribota yüklenir. Ada limanında vinçle yerleştirilir. Feribot nakliyesi koordinasyonu tarafımızca yapılır.

## 6. Ek Optimizasyon İpuçları

- **Yorum teşviki:** Her teslimattan sonra müşteriden Google yorumu talep edin. Yorum kartı/QR kodu hazırlayın.
- **Yorum yanıtlama:** Tüm yorumlara 24 saat içinde, kişiselleştirilmiş yanıt verin. Olumlu ve olumsuz tüm yorumlara profesyonelce cevap yazın.
- **Fotoğraf güncelleme:** Her ayın ilk haftası en az 3-5 yeni fotoğraf yükleyin.
- **Post sıklığı:** Haftada minimum 2 post yayınlayın.
- **Mesajlaşma:** GMB mesajlaşmayı aktif edin ve 1 saat içinde yanıtlayın.
- **Booking butonu:** "Randevu al" veya "Teklif iste" butonunu aktif edin.
- **UTM parametreleri:** GMB link tıklamalarını Analytics'te takip etmek için UTM ekleyin.
