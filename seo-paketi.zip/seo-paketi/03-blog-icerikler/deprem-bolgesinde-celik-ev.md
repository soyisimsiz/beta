---
title: "Deprem Bölgesinde Çelik Ev – Güvenlik, Performans ve Çanakkale"
meta_title: "Deprem Bölgesinde Çelik Ev | Güvenlik ve Performans Rehberi"
meta_description: "Deprem bölgesinde çelik ev güvenli mi? Çelik evin deprem performansı, test sonuçları ve Çanakkale için önemi. Detaylı rehber."
date: 2026-04-01
author: Beta Yapı İnşaat
keywords: deprem bölgesinde çelik ev, çelik ev deprem dayanımı, depreme dayanıklı ev
---

# Deprem Bölgesinde Çelik Ev – Güvenlik, Performans ve Çanakkale

**TL;DR:** Çelik evler, hafif yapıları ve esnek çelik karkas sistemleri sayesinde deprem bölgelerinde en güvenli yapı tiplerinden biridir. Betonarme yapılara göre 3-4 kat daha hafif olan çelik evler, deprem kuvvetlerini verimli şekilde sönümler. Çanakkale 1. derece deprem bölgesinde yer alır ve çelik ev bu bölge için ideal seçimdir.

## Türkiye'nin Deprem Gerçeği

Türkiye, dünyanın en aktif deprem kuşaklarından birinde yer almaktadır. Kuzey Anadolu Fay Hattı, Doğu Anadolu Fay Hattı ve Batı Anadolu Graben sistemleri, ülkenin büyük bölümünü deprem riski altında bırakır.

Çanakkale, Kuzey Anadolu Fay Hattı'nın batı uzantısına yakınlığıyla 1. derece deprem bölgesindedir. 1912 Mürefte-Şarköy depremi (7.3 büyüklüğünde) bölgenin deprem potansiyelini tarihsel olarak kanıtlamıştır.

## Çelik Evin Deprem Performansı

### Hafiflik Avantajı
Deprem kuvveti, yapının ağırlığıyla doğru orantılıdır. Ne kadar ağır yapı, o kadar büyük deprem kuvveti. Çelik ev, aynı metrekaredeki betonarme yapıya göre 3-4 kat daha hafiftir. Bu, deprem sırasında yapıya etkiyen kuvvetleri dramatik şekilde azaltır.

| Yapı Tipi | Yaklaşık Ağırlık (100 m²) |
|-----------|---------------------------|
| Betonarme | 150-200 ton |
| Çelik ev | 35-50 ton |
| Oran | 3-4x daha hafif |

### Elastik Davranış
Çelik, elastik bir malzemedir. Deprem sırasında deforme olup enerjiyi absorbe eder ve sarsıntı sona erdiğinde orijinal formuna geri döner. Beton ise kırılgan bir malzemedir; belirli bir yükün üzerinde çatlar ve parçalanır. Bu fark, can güvenliği açısından kritiktir.

### Sünek Birleşimler
Çelik karkas sistemde birleşim noktaları vidalı veya bulonlu olup, enerji sönümleme kapasitesine sahiptir. Deprem sırasında birleşimler kontrollü şekilde hareket ederek enerjiyi dağıtır. Betonarme yapılarda ise birleşim noktaları çoğunlukla rijit olup, ani kırılma riski taşır.

### Hafif Duvar Sistemi
Çelik evlerde duvarlar taşıyıcı değildir; yük çelik karkas tarafından taşınır. Duvar panelleri hafiftir ve depremde düşme/devrilme riski minimumdur. Betonarme yapılarda ise tuğla duvarlar depremde göçerek yaralanmalara neden olabilir.

## TBDY 2018 ve Çelik Ev Uyumu

Türkiye Bina Deprem Yönetmeliği (TBDY 2018), tüm yapı tiplerinin deprem güvenliğini düzenler. Beta Yapı İnşaat çelik evleri:

- TBDY 2018 kriterlerinin tamamını karşılar
- Deprem bölgesi parametrelerine göre hesaplanır
- Statik analiz yazılımlarıyla tasarlanır
- Rüzgâr ve kar yükleri de hesaba katılır
- Bağımsız yapı denetim firması gözetiminde kurulur

## Çanakkale İçin Neden Çelik Ev?

Çanakkale'nin deprem riskinin yanı sıra, bölgenin iklim özellikleri de çelik evi öne çıkarır:

- **Deprem riski:** 1. derece bölge, çelik evin hafifliği ve esnekliği hayat kurtarır
- **Nem ve tuz:** Galvanizli çelik profiller korozyona dayanıklıdır
- **Rüzgâr:** Hafif ama sağlam yapı, rüzgâr yüküne esnek davranır
- **Hızlı yapım:** Deprem sonrası acil barınma ihtiyacında hızla kurulabilir

## Deprem Sonrası Çelik Ev Durumu

Büyük depremlerden sonra çelik evlerin performansı incelendiğinde:

- Yapısal hasar minimum düzeyde kalır
- Onarım maliyeti düşüktür
- Yapı hızla yeniden kullanılabilir hale gelir
- Can kaybı riski betonarmeye göre çok düşüktür

[Çanakkale çelik ev çözümlerimiz →](/celik-ev-canakkale/)

[Prefabrik ev deprem performansı →](/prefabrik-ev-canakkale/)

## Sonuç

Çanakkale gibi aktif deprem bölgelerinde çelik ev, aile güvenliğiniz için yapabileceğiniz en akıllı yatırımlardan biridir. Beta Yapı İnşaat olarak TBDY 2018 uyumlu, depreme dayanıklı çelik evler üretiyoruz. 93+ projemizle kanıtlanmış güvence için bize ulaşın.
