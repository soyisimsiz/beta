---
title: "Konteyner Ev Ruhsat Rehberi 2026 – Yasal Süreç ve Gerekli Belgeler"
meta_title: "Konteyner Ev Ruhsat Rehberi 2026 | Yasal Süreç Adımları"
meta_description: "Konteyner ev için ruhsat gerekli mi? 2026 güncel mevzuatı, başvuru adımları, gerekli belgeler ve istisnalar. Kapsamlı rehber."
date: 2026-02-15
author: Beta Yapı İnşaat
keywords: konteyner ev ruhsat, konteyner ev izin, konteyner ev yasal mı
---

# Konteyner Ev Ruhsat Rehberi 2026 – Yasal Süreç ve Gerekli Belgeler

**TL;DR:** Kalıcı kullanım amaçlı konteyner evler için yapı ruhsatı zorunludur. Geçici ve tarımsal amaçlı bazı kullanımlar istisna kapsamında olabilir ancak belediyeden belediyeye farklılık gösterir. Ruhsatsız yapı ciddi para cezaları ve yıkım kararıyla sonuçlanabilir. Bu rehberde adım adım ruhsat sürecini, gerekli belgeleri ve istisnaları bulacaksınız.

## Konteyner Ev İçin Ruhsat Gerekli mi?

Kısa cevap: çoğu durumda evet. Türkiye'de 3194 sayılı İmar Kanunu'na göre, kalıcı olarak bir yere konumlandırılan ve konut veya işyeri olarak kullanılan her yapı için yapı ruhsatı alınması zorunludur. Konteyner evler de bu kapsama girer.

Ancak bazı istisnai durumlar bulunmaktadır:

- **Geçici yapılar:** Şantiye ofisi, geçici depolama gibi kısa süreli kullanımlar için farklı prosedürler uygulanabilir.
- **Tarımsal yapılar:** Tarım arazilerinde, tarımsal faaliyet amaçlı küçük yapılar için bazı muafiyetler söz konusu olabilir. Ancak bu, il ve ilçe yönetmeliklerine göre değişir.
- **Taşınır yapılar:** Kalıcı olarak zemine sabitlenmemiş, tekerlekli veya taşınabilir nitelikteki yapılar için farklı değerlendirmeler yapılabilir.

## Ruhsat Başvuru Süreci: Adım Adım

### 1. Arazi Uygunluk Kontrolü

Başvurudan önce arsanızın imar durumunu kontrol edin:

- Belediyeden imar durumu belgesi alın
- Arsanın konut yapımına uygun olup olmadığını doğrulayın
- Sit alanı, orman alanı veya kıyı kenar çizgisi kısıtlamalarını kontrol edin
- Çanakkale'de özellikle Gelibolu Milli Parkı, Truva çevresi ve kıyı bölgelerinde özel kısıtlamalar mevcuttur

### 2. Zemin Etüdü

- Yetkilendirilmiş bir jeoloji firmasına zemin etüdü yaptırın
- Rapor, temel tasarımı ve yapısal hesaplar için gereklidir
- Çanakkale'nin farklı bölgelerinde zemin yapısı değişkenlik gösterir

### 3. Mimari ve Statik Proje

- Lisanslı bir mimar tarafından mimari proje hazırlanmalıdır
- İnşaat mühendisi tarafından statik hesaplar yapılmalıdır
- Konteyner evin teknik çizimleri ve yerleşim planı dahil edilmelidir

### 4. Ruhsat Başvurusu

Belediyeye başvuru için gerekli belgeler:

| Belge | Açıklama |
|-------|----------|
| Tapu fotokopisi | Arsa tapusu |
| İmar durumu belgesi | Belediyeden alınır |
| Zemin etüdü raporu | Jeoloji firmasından |
| Mimari proje | 3 takım |
| Statik proje | 3 takım |
| Elektrik projesi | 3 takım |
| Mekanik tesisat projesi | 3 takım |
| Yapı denetim sözleşmesi | Yapı denetim firmasıyla |
| Müteahhit yetki belgesi | Yapımcı firmadan |
| Nüfus cüzdanı fotokopisi | Yapı sahibi |
| Vergi levhası | (tüzel kişi ise) |

### 5. Yapı Denetim

- 4708 sayılı Yapı Denetimi Kanunu gereği, yapı denetim firması gözetiminde inşaat yapılmalıdır
- Konteyner evler de bu denetime tabidir
- Yapı denetim maliyeti yapı bedelinin %1.5-3'ü civarındadır

### 6. İskan (Yapı Kullanma İzni)

- İnşaat tamamlandıktan sonra iskan belgesi alınmalıdır
- İskan belgesi; tapu, kredi ve sigorta işlemleri için gereklidir
- Belediye teknik ekibi yerinde kontrol yapar

## Ruhsatsız Konteyner Evin Riskleri

- **Para cezası:** İmar Kanunu'na göre ruhsatsız yapı sahiplerine ağır para cezaları uygulanır
- **Yıkım kararı:** Belediye encümeni, ruhsatsız yapıların yıkılmasına karar verebilir
- **Kredi kullanamama:** İskan belgesi olmadan konut kredisi kullanılamaz
- **Sigorta yapılamama:** DASK ve konut sigortası iskan belgesi gerektirir
- **Tapu sorunu:** Ruhsatsız yapılar tapuya tescil edilemez
- **Cezai sorumluluk:** Tekrarlayan ihlallerde hapis cezası gündeme gelebilir

## Çanakkale'de Konteyner Ev Ruhsat Süreci

Çanakkale'nin kendine özgü ruhsat dinamikleri vardır. Gelibolu Yarımadası Tarihi Milli Park alanı, Truva arkeolojik sit alanı, Bozcaada ve Gökçeada'nın ada belediyeleri, kıyı kenar çizgisi düzenlemeleri ve askeri alan kısıtlamaları, standart ruhsat sürecine ek katmanlar ekler.

Beta Yapı İnşaat olarak Çanakkale merkez ve 12 ilçesinde ruhsat süreçlerinde uzmanız. Projenizin başından sonuna kadar tüm bürokratik işlemleri sizin adınıza takip ediyoruz.

[Çanakkale'de konteyner ev çözümlerimiz →](/konteyner-ev-canakkale/)

[Prefabrik ev ruhsat süreci hakkında detay →](/prefabrik-ev-canakkale/)

## Sonuç

Konteyner ev yaptırmadan önce ruhsat sürecini doğru planlamak, ileride ciddi sorunların önüne geçer. Beta Yapı İnşaat olarak arazi seçiminden ruhsat alımına, yapı denetiminden iskan belgesine kadar her aşamada yanınızdayız. Ücretsiz danışmanlık için bize ulaşın.
